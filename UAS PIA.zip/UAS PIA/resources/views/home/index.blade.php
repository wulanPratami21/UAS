@extends('layouts.app')

@section('title', 'Home')

@section('content')

<h1 align="center"><img src="/foto/logo.jpg" width="500" height="400"></h1>

@endsection